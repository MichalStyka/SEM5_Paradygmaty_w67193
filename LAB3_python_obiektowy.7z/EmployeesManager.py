# from Employee import Employee
#
# class EmployeesManager:
#     def __init__(self,name,age,salary):
#         self.name = name
#         self.age = age
#         self.salary = salary
#
#     def opis(self):
#         return f"{self.name}\t{self.age}\t{self.salary}"
#
#     def dodaj(self):
#
# #         Employee.append()
# #
# # Employees =[
# # Employee("Michal S","22",3000),
# # Employee("Michak S","22",3000)
# # ]
#
# #print(Employee1.opis())