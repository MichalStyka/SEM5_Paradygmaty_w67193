class Employee:
    def __init__(self,name,age,salary):
        self.name = name
        self.age = age
        self.salary = salary

    def opis(self):
        return f"{self.name}\t{self.age}\t{self.salary}"

    def dodaj(self):
        print("Type data for a new Employee: \n")
        name = input(" Name and Lastname: \n")
        age = int(input("Age: \n"))
        salary = int(input("Salary: \n"))
        Employee(name,age,salary)
        ListaPracownikow.append(Employee)

ListaPracownikow = []
Employee1 = Employee("Michal S","22",3000)


for p in range(len(ListaPracownikow)):
    print(ListaPracownikow[p].opis())
